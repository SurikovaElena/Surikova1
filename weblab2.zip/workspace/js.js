var imagen1 = "350";
	var imagen2 = "150";
function f3(im) {
	
	if(im.height == imagen1) im.height = imagen2;
  else im.height = imagen1;
}
