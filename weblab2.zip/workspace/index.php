<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" 
  "http://www.w3.org/TR/html4/strict.dtd">
<html>
	
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>AmberColor</title>
    <style>  body {
    background:  url(zagl1.jpg) no-repeat;
	background-size: cover;
	height: 100%;
	background-attachment: fixed;
   } 
   </style>
  <meta charset="utf-8">
  <link rel="stylesheet" href="gl.css">
    <script src="js.js" defer ></script>
  </head>
 
	<body>

 <p > <a href="index.html"> <img src="l3.png" width="30%" height="20%" border="0" alt="Пример" align="right" ></a></p>
 
 <form id="application" action=" add.php" method="POST" name=" application ">
   <input name="name" id="zayavkaName" maxlength="20" placeholder="Введите ваше имя" required />
   <input name="email" type="email" id="applicationEmail" maxlength="20" placeholder="Введите ваш E-mail" required />
   <input name="telephone" type="Tel" id="applicationTelephone" maxlength="20" placeholder="Введите ваш телефон" required/>
   <input class = "submit" type = "submit" placeholder = "Добавить пользователя" reqiured />
</form>
 <p>  &nbsp; </p> 
  <p>  &nbsp; </p> 
  <p> &nbsp;  </p> 
  <p> &nbsp;  </p>
   <p> &nbsp;  </p>
<div id="menu_itc ">
 <div>
 <ul class="menu">			
				<li>
					<a href="#">  Услуги для мужчин</a> 
					<ul>
						<li> <a href="Km.php">Услуги салона красоты для мужчин</a> 
							<ul>
								<li> <a href="s1.php"> Все для волос </a> 
									<ul>
										<li> <a href="#"> Покраска волос </a> </li>
										<li> <a href="#"> Стрижка </a></li>
										<li> <a href="#"> Миллирование </a></li>
										<li> <a href="#"> Стрижка бороды</a></li>
									</ul>
								</li>
								<li> <a href="s2.html"> Все для тела </a></li>
							</ul>
						</li>
						<li> <a href="auto.html">Авто-услуги для мужчин</a>
							<ul>
								<li> <a href="#"> Мойка автомобилей </a> </li>
								<li> <a href="#"> Технический осмотр авто </a></li>
								<li> <a href="#"> Ремонт авто </a></li>
								<li> <a href="#"> Тюнинг-ателье </a></li>
								<li> <a href="#"> Заправка авто </a></li>
							</ul>
						</li>
						<li> <a href="ko.html">Комната отдыха</a> 
							<ul>
								<li> <a href="#"> Бильярд </a> </li>
								<li> <a href="#"> Боулинг </a></li>
								<li> <a href="#"> Фитнес-Центр </a></li>
								<li> <a href="#"> Кафе-бар </a></li>
								<li> <a href="#"> Кинозал </a></li>
								<li> <a href="#"> Настольные игры </a></li>
								<li> <a href="#"> Караоке-бар </a></li>
								<li> <a href="#"> Танцы </a></li>
								<li> <a href="#"> Ночной клуб </a></li>
							</ul>
						</li>
					</ul>
				  </li>
				  <li>
					<a href="#">  Услуги для женщин</a>
					<ul>
						<li> <a href="kw.html">Услуги салона красоты для женщин</a>
							<ul>
								<li> <a href="#"> Все для волос </a> 
									<ul>
										<li> <a href="#"> Покраска волос </a> </li>
										<li> <a href="#"> Стрижка </a></li>
										<li> <a href="#"> Миллирование </a></li>
										<li> <a href="#"> Био-Завивка </a></li>
										<li> <a href="#"> Прическа </a></li>
										<li> <a href="#"> Хим-Завивка </a></li>
										<li> <a href="#"> Кератиновое выпрямление </a></li>
										<li> <a href="#"> Ламинирование </a></li>
										<li> <a href="#"> Колорирование </a></li>
									</ul>
								</li>
								<li> <a href="#"> Все для тела </a></li>
							</ul>
						</li>
						<li> <a href="auto.html">Авто-услуги для женщин</a>
							<ul>
								<li> <a href="#"> Мойка автомобилей </a> </li>
								<li> <a href="#"> Технический осмотр авто </a></li>
								<li> <a href="#"> Ремонт авто </a></li>
								<li> <a href="#"> Тюнинг-ателье </a></li>
								<li> <a href="#"> Заправка авто </a></li>
							</ul>
						</li>
						<li> <a href="ko.html">Комната отдыха</a> 
							<ul>
								<li> <a href="#"> Бильярд </a> </li>
								<li> <a href="#"> Боулинг </a></li>
								<li> <a href="#"> Фитнес-Центр </a></li>
								<li> <a href="#"> Кафе-бар </a></li>
								<li> <a href="#"> Кинозал </a></li>
								<li> <a href="#"> Настольные игры </a></li>
								<li> <a href="#"> Караоке-бар </a></li>
								<li> <a href="#"> Танцы </a></li>
								<li> <a href="#"> Ночной клуб </a></li>
							</ul>
						</li>
					</ul>
				  </li>
				  <li>
					<a href="#">   Услуги для детей</a>
					<ul>
						<li> <a href="#">Услуги салона красоты для детей</a>
							<ul>
								<li> <a href="#"> Все для волос </a> </li>
								<li> <a href="#"> Все для тела </a></li>
							</ul>
						</li>
						<li> <a href="#">Игровая комната</a> </li>
						<li> <a href="#">Услуги няни</a> </li>
					</ul>
				  </li>
				  <li>
					<a href="#">   Услуги для животных</a>
					<ul>
						<li> <a href="#">Услуги салона красоты для живаотных</a> </li>
						<li> <a href="#">Игровая комната для животных</a> 
							<ul>
								<li> <a href="#"> Дрессировка </a> </li>
								<li> <a href="#"> Временная передержка </a></li>
								<li> <a href="#"> Приют для бездомных животных </a></li>
							</ul>
						</li>
					</ul>
				  </li>
				  <li>
					<a href="gal.html">Галерея</a>
				  </li>
				  
				
		</ul>
 </div> 
 
 <p>  &nbsp; </p> 
  <p>  &nbsp; </p> 
  <p> &nbsp;  </p> 
  <p> &nbsp;  </p>
  <p>  &nbsp; </p> 
  <p>  &nbsp; </p> 
  <p> &nbsp;  </p> 
  <p> &nbsp;  </p>
  <p>  &nbsp; </p> 
  <p>  &nbsp; </p> 
  <p> &nbsp;  </p> 

 <marquee behavior="scroll" direction="left"> 
 <span style="color:#660033"> Мы всегда рады видеть вас в нашем салоне красоты и отдыха для всей семьи "AmberColor"!</span> </marquee>

 </body>
</html>
